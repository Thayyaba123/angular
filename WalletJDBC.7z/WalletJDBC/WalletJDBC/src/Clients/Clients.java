package Clients;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Customer.Customer;
import Customer.MoneyTran;

public class Clients {
	public static Connection connect() throws ClassNotFoundException, SQLException
	{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
			return con;	

	}
}
