package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;



import Clients.Clients;
import Customer.Customer;
import Customer.MoneyTran;
import WalletException.WaExceptions;

public class Bank_Dao implements Bank_Dao_Interface {
	
	
	
	
//add customer
public int addCustomer(Customer c) throws WaExceptions, SQLException, ClassNotFoundException {
		
	Connection c1=Clients.connect();
	Statement stmt=c1.createStatement();
	PreparedStatement pst=c1.prepareStatement("INSERT INTO CUSTOMER VALUES(?,?,?,?,?)");
	pst.setString(1,c.getName());
	pst.setString(2, c.getAddress());
	pst.setString(3, c.getPhone());
	pst.setString(4, c.getAccountno());
	pst.setInt(5, c.getId());
	pst.executeUpdate();
	return 0;
	}
//get balance
	public Customer searchId(int id1) throws WaExceptions, SQLException,ClassNotFoundException {
	
		Connection c2=Clients.connect();
		Statement stmt=c2.createStatement();
		ResultSet res=stmt.executeQuery("SELECT * FROM  WHERE ACCOUNTNO=' "+id1+" ' ");
		//System.out.println(res);
		while(res.next())
		{
			int id=res.getInt(1);
			String name=res.getString(2);
			String address=res.getString(3);
		    String phone=res.getString(4);
			double balance =res.getDouble(5);
			String accountno=res.getString(6);
			Customer c=new Customer(name,address,phone,id,accountno, balance);
			return c;
	}
		
		
		c2.commit();
		return null;
		
	}
//deposite money
	public void searchId(int id2, double wamount) throws WaExceptions, SQLException,ClassNotFoundException{
		Connection c=Clients.connect();
		Statement stmt=c.createStatement();
			ResultSet res1 =stmt.executeQuery("update CUSTOMER set balance='"+wamount+"'where ACCOUNTNO='"+id2+"'"); 
			 
		/*while(res1.next())
		{
			double bal =res1.getDouble(5);
			System.out.println(bal);
			//res1.updateDouble(5, amt);
			res1.updateRow();
			
	}*/
		c.commit();
		
		
		
		
		
}
//withdraw amount
	public void searchwithdrawId(int id3, double wamount) throws WaExceptions ,SQLException, ClassNotFoundException{
		Connection c=Clients.connect();
		Statement stmt=c.createStatement();
		ResultSet res1 =stmt.executeQuery("update CUSTOMER set balance='"+wamount+"'where ACCOUNTNO='"+id3+"'"); 	 
				c.commit();
		
	}

	
	
//fund transfer
	public void searchfundId(int id31, double famount) throws WaExceptions, SQLException, ClassNotFoundException{
		Connection c=Clients.connect();
		Statement stmt=c.createStatement();
		ResultSet res1 =stmt.executeQuery("update CUSTOMER set balance='"+famount+"'where ACCOUNTNO='"+id31+"'"); 	 
				c.commit();
		
	}
	public Customer searchId1(int id8) throws WaExceptions, SQLException,ClassNotFoundException {
		
		Connection c2=Clients.connect();
		Statement stmt=c2.createStatement();
		ResultSet res=stmt.executeQuery("SELECT * FROM  WHERE ACCOUNTNO=' "+id8+" ' ");
		//System.out.println(res);
		while(res.next())
		{
			int id=res.getInt(1);
			String name=res.getString(2);
			String address=res.getString(3);
		    String phone=res.getString(4);
			double balance =res.getDouble(5);
			String accountno=res.getString(6);
			Customer c=new Customer(name,address,phone,id,accountno, balance);
			return c;
	}
		
		
		c2.commit();
		return null;
	


}
}
