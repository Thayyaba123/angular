package WalletException;

public class WaExceptions extends Exception {

		public  WaExceptions(String message) {
			super(message);
		}

}
