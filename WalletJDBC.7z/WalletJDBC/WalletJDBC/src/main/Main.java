package main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import Customer.Customer;
import Customer.MoneyTran;
import WalletException.WaExceptions;
import service.Bank_Service;

public class Main {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Scanner x = null;

		Bank_Service s = new Bank_Service();

		String continueChoice = "";

		do {

			System.out.println("****** WALLET APPLICATION ******");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT");
			System.out.println("4.WITHDRAW");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.GET ACCOUNT HOLDER DETAILS");
			System.out.println("8.EXIT");
			int choice = 0;
			boolean choiceFlag = false;

			do {
				x = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = x.nextInt();
					choiceFlag = true;

					switch (choice) {
//creating the account
					case 1:

						String name = "";
						boolean nameFlag = false;

						do {
							x = new Scanner(System.in);
							System.out.println("Enter  name");
							try {
								name = x.nextLine();
								s.validateName(name);
								nameFlag = true;
								break;
							} catch (WaExceptions e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						String address = "";
						boolean addressFlag= false;
						do {
						x = new Scanner(System.in);
							System.out.println("Enter address:");
							try {
								address = x.nextLine();
								s.validateAddress(address);
								addressFlag = true;
								break;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("address should be alphabets only");
							} catch (WaExceptions e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);

						String phone = "";
						boolean phoneFlag= false;
						do {
						x = new Scanner(System.in);
							System.out.println("Enter phone number:");
							try {
								phone = x.nextLine();
								s.validatePhone(phone);
								addressFlag = true;
								break;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("please enter valid number");
							} catch (WaExceptions e) {
								phoneFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!phoneFlag);
						String account = null;
						boolean amountFlag= false;
						do {
						x = new Scanner(System.in);
							System.out.println("Enter account number:");
							try {
								account = x.nextLine();
								s.validateAccount(account);
								amountFlag = true;
								break;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("account number shound contain numbers only");
							} catch (WaExceptions e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!amountFlag);
						
						int id = (int) (Math.random() * 1000);
                            Customer c = new Customer(name,address,phone,account,id);
                            
					
						System.out.println("id: " + id);
						System.out.println("**** aCCOUNT GENERATED SUCCESSFULLY*****");

						
						break;
						//showing balance
					case 2:

						int id1 = 0;
						boolean idFalg = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id1 = x.nextInt();
								idFalg = true;
						
								try {
									Customer c1 = s.searchId(id1);
									 
									System.out.println("your balance is:"+c1.getBalance());
									
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								idFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!idFalg);

						break;
//depositing the amount in wallet
					case 3:

						int id2 = 0;
						boolean id2Falg = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id2 = x.nextInt();
								idFalg = true;
						System.out.println("enter the amount to diposite");
								try {
									double amount1=0.00;
									amount1=x.nextDouble();
									Customer c1=s.searchId(id2);
									double d=c1.getBalance();
									System.out.println("your deposit amount is:"+amount1);
									double amount=c1.setBalance(d+amount1);
									s.searchId(id2,amount);
									System.out.println("total amount is"+amount);
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								idFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!idFalg);

						
						break;
//withdraw the amount
					case 4:
						int id3 = 0;
						boolean id3Falg = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id3 = x.nextInt();
								idFalg = true;
						System.out.println("enter the amount to diposite");
								try {
									double amount2=0.00;
									amount2=x.nextDouble();
									Customer c1=s.searchId(id3);
									double d=c1.getBalance();
									System.out.println("your withdraw amount is:"+amount2);
									if(d>amount2)
									{
									double wamount=c1.setBalance(d-amount2);
									s.searchwithdrawId(id3,wamount);
									System.out.println("total amount is"+wamount);
									}
									else
									{
										System.out.println("check your balance");
									}
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								idFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!idFalg);

						
						break;
						
//fund transferring
					case 5:
						int id31 = 0;
						boolean id3Falg1 = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id31 = x.nextInt();
								System.out.println("Enter wlallet id:");
								int id4 = x.nextInt();
								id3Falg1 = true;
						System.out.println("enter the amount to diposite");
								try {
									double famount=0.00;
									famount=x.nextDouble();
									Customer c1=s.searchId(id31);
									double d=c1.getBalance();
									System.out.println("your fund transfer amount is:"+famount);
									if(d>famount)
									{
									double wamount=c1.setBalance(d-famount);
									s.searchfundId(id31,famount);
									System.out.println("total amount is"+famount);
									}
									else
									{
										System.out.println("check your balance");
									}
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								idFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!id3Falg1);

						
						break;
						
						
						//printing transaction
						/*
						 * case 6: int id6= 0; boolean id6Falg = false; do { x = new Scanner(System.in);
						 * System.out.println("Enter wlallet id:"); try { id1 = x.nextInt(); idFalg =
						 * true;
						 * 
						 * List<MoneyTran> mon= null; try { mon = s.getTransaction(); for (MoneyTran out
						 * : mon) { System.out.println(out); } } catch (WaExceptions e) {
						 * System.err.println(e.getMessage()); }
						 * 
						 * } catch (InputMismatchException e) { idFalg = false;
						 * System.err.println("Id should be digits"); } } while (!idFalg);
						 */

						//break;
					case 6:
						int id8 = 0;
						boolean id8Falg = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id1 = x.nextInt();
								idFalg = true;
						
								try {
									Customer c1 = s.searchId1(id8);
									System.out.println("NAME:"+c1.getName());
									System.out.println("ADDRESS:"+c1.getAddress());
									System.out.println("PHONE NUMBER:"+c1.getPhone());
									System.out.println("ACCOUNT NUMBER:"+c1.getAccountno());
									System.out.println("WALLET ID:"+c1.getId());
									System.out.println("BALANCE:"+c1.getBalance());
									
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								id8Falg = false;
								System.err.println("Id should be digits");
							}
						} while (!id8Falg);

						break;
					case 7:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("select from the above only");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			x = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = x.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		x.close();
	}
}
