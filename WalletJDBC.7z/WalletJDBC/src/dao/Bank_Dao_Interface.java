package dao;

import java.sql.SQLException;
import java.util.List;

import Customer.Customer;
import Customer.MoneyTran;
import WalletException.WaExceptions;



public interface Bank_Dao_Interface {
	public int addCustomer(Customer c) throws WaExceptions, SQLException, ClassNotFoundException;
	public Customer searchId(int id1) throws WaExceptions, WaExceptions, SQLException, ClassNotFoundException;
	public double searchId(int id2, double amount1) throws WaExceptions;
	public double searchwithdrawId(int id3, double amount2) throws WaExceptions;
	public double searchfundId(int id4, double amount3) throws WaExceptions;
	public List<MoneyTran> getTransaction()  throws WaExceptions;
	public List<Customer> getDetails()throws WaExceptions;
}
