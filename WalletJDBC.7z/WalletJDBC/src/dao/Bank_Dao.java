package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;

import com.cg.Entity.Account;
import com.cg.Util.JDBC;

import Clients.Clients;
import Customer.Customer;
import Customer.MoneyTran;
import WalletException.WaExceptions;

public class Bank_Dao implements Bank_Dao_Interface {
	
	
	
	public List<Customer> getDetails()throws WaExceptions
	{
		return Clients.list;
	}
//add customer
public int addCustomer(Customer c) throws WaExceptions, SQLException, ClassNotFoundException {
		
	Connection c1=Clients.connect();
	Statement stmt=c1.createStatement();
	PreparedStatement pst=c1.prepareStatement("INSERT INTO CUSTOMER VALUES(?,?,?,?,?)");
	pst.setString(1,c.getName());
	pst.setString(2, c.getAddress());
	pst.setString(3, c.getPhone());
	pst.setString(4, c.getAccountno());
	pst.setInt(5, c.getId());
	pst.executeUpdate();
	return 0;
	}
//get balance
	public Customer searchId(int id1) throws WaExceptions, SQLException,ClassNotFoundException {
	
		Connection c2=Clients.connect();
		Statement stmt=c2.createStatement();
		boolean flag = false;
		ResultSet res=stmt.executeQuery("SELECT * FROM  WHERE ACCOUNTNO=' "+id1+" ' ");
		//System.out.println(res);
		while(res.next())
		{
			int id=res.getInt(1);
			String name=res.getString(2);
			String address=res.getString(3);
		    String phone=res.getString(4);
			double balance =res.getDouble(5);
			String accountno=res.getString(6);
			Customer c=new Customer(name,address,phone,id,accountno, balance);
			return c;	
			flag = true;
			break;
	}
		if (flag == false) {
			throw new WaExceptions("No data present with the given id");
		}

		c2.commit();
		return null;
		
	}
//deposite money
	public double searchId(int id2, double amount) throws WaExceptions {
		Connection c=JDBC.connect();
		Statement stmt=c.createStatement();
			ResultSet res1 =stmt.executeQuery("update ACCOUNT set balance='"+amt+"'where ACCOUNTNO='"+acc+"'"); 
			 
		/*while(res1.next())
		{
			double bal =res1.getDouble(5);
			System.out.println(bal);
			//res1.updateDouble(5, amt);
			res1.updateRow();
			
	}*/
		c.commit();
		
		}
		if (flag == false) {
			throw new WaExceptions("No data present with the given id or check ba");
		}
		
		return customerData;
}
//withdraw amount
	public double searchwithdrawId(int id3, double amount2) throws WaExceptions{
		List<Customer> list = Clients.getList();
		double customerData1 = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if ((customer.getId() == id3)&&(customer.getBalance()>amount2)) {
				customerData1 = customer.getBalance()-amount2;
			customer.setBalance(customerData1);
				LocalDateTime now=LocalDateTime.now();
				MoneyTran m=new MoneyTran("withdraw",amount2,customerData1,now,id3);;
						Clients.li.add(m);
					flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}
		
		return customerData1;
	
	}
//fund transfer
	public double searchfundId(int id4, double amount3) throws WaExceptions{
		List<Customer> list = Clients.getList();
		double customerData2 = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if ((customer.getId() == id4)&&(customer.getBalance()>amount3)) {
				customerData2 = customer.getBalance()-amount3;
			customer.setBalance(customerData2);
			LocalDateTime now=LocalDateTime.now();
			MoneyTran m=new MoneyTran("fund transfer",amount3,customerData2,now,id4);
							Clients.li.add(m);
						flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No data present with the given id");
		}
		return customerData2;
	
	}
//print transaction
	public List<MoneyTran> getTransaction()  throws WaExceptions{
		
		return Clients.li;
	}

}
