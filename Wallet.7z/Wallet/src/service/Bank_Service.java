package service;

import java.util.List;
import java.util.regex.Pattern;

import Customer.Customer;
import Customer.MoneyTran;
import WalletException.WaExceptions;
import dao.Bank_Dao;

public class Bank_Service implements Bank_Service_Interface {
	Bank_Dao d=new Bank_Dao();
	public void validateName(String name) throws WaExceptions {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]+";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new WaExceptions("first letter should be capital ");
		}
	}

	public void validateAddress(String address) throws WaExceptions {
		String addressRegEx = "[a-zA-Z ]+";
		if (!Pattern.matches(addressRegEx, address)) {
			throw new WaExceptions("address should be alphabets only");
		}
		
	}

	public void validatePhone(String phone) throws WaExceptions {
		String phoneRegEx = "[7-9]{1}[0-9]{9}";
		if (!Pattern.matches(phoneRegEx,phone)) {
			throw new WaExceptions("enter valid number");
		}
		
	}

	public void validateAccount(String account) throws WaExceptions {
		String accountRegEx = "[0-9]{10}";
		if (!Pattern.matches(accountRegEx,account)) {
			throw new WaExceptions("enter valid number");
		}
		
	}

	public int addCustomer(Customer c) throws WaExceptions {
		return d.addCustomer(c);
	
	}
	

	public double searchId(int id1) throws WaExceptions {
	
		return d.searchId(id1);
	}

	public double searchId(int id2, double amount1) throws WaExceptions {
	
		return d.searchId(id2,amount1);
	}

	public double searchwithdrawId(int id3, double amount2) throws WaExceptions {
		
		return d.searchwithdrawId(id3,amount2);
	}

	public double searchfundId(int id4, double amount3) throws WaExceptions {
		
		return d.searchfundId(id4,amount3);
	}

	public List<MoneyTran> getTransaction()  throws WaExceptions{

		return d.getTransaction();
	}



}
