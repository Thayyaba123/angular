package dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import Clients.Clients;
import Customer.Customer;
import Customer.MoneyTran;
import WalletException.WaExceptions;

public class Bank_Dao implements Bank_Dao_Interface {
	
	
	
	//add customer
public int addCustomer(Customer c) throws WaExceptions {
		
		int id = (int) (Math.random() * 1000);
		c.setId(id);

		List<Customer> c2 = Clients.getList();
		c2.add(c);
	return id;
	}
//get balance
	public double searchId(int id1) throws WaExceptions {
	

		List<Customer> list = Clients.getList();
		double customerData = 0.00;
		boolean flag = false;

		for (Customer balance : list) {
			if (balance.getId() == id1) {
			customerData = balance.getBalance();
			
			
			System.out.println(Clients.li);
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No data present with the given id");
		}

		return customerData;
	}
//deposite money
	public double searchId(int id2, double amount1) throws WaExceptions {
		List<Customer> list = Clients.getList();
		double customerData = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id2) {
				customerData = customer.getBalance()+amount1;
			customer.setBalance(customerData);
			LocalDateTime now=LocalDateTime.now();
MoneyTran m=new MoneyTran("deposite",amount1,customerData,now,id2);
			Clients.li.add(m);
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No data present with the given id");
		}
		
		return customerData;
}
//withdraw amount
	public double searchwithdrawId(int id3, double amount2) throws WaExceptions{
		List<Customer> list = Clients.getList();
		double customerData1 = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id3) {
				customerData1 = customer.getBalance()-amount2;
			customer.setBalance(customerData1);
				LocalDateTime now=LocalDateTime.now();
				MoneyTran m=new MoneyTran("deposite",amount2,customerData1,now,id3);;
						Clients.li.add(m);
					flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}
		
		return customerData1;
	
	}
//fund transfer
	public double searchfundId(int id4, double amount3) throws WaExceptions{
		List<Customer> list = Clients.getList();
		double customerData2 = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id4) {
				
		
				customerData2 = customer.getBalance()-amount3;
			customer.setBalance(customerData2);
			LocalDateTime now=LocalDateTime.now();
			MoneyTran m=new MoneyTran("fund transfer",amount3,customerData2,now,id4);
							Clients.li.add(m);
						flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No data present with the given id");
		}
		return customerData2;
	
	}
//print transaction
	public List<MoneyTran> getTransaction()  throws WaExceptions{
		
		return Clients.li;
	}

}
