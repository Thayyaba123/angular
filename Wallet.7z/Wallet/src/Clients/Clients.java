package Clients;

import java.util.ArrayList;
import java.util.List;

import Customer.Customer;
import Customer.MoneyTran;

public class Clients {
	public static List<Customer>list=new ArrayList<>();
	public static List<MoneyTran>li=new ArrayList<MoneyTran>();
	
	public static List<Customer> getList()
	{
		return list;
	}
	public static void setlist(List<Customer>list)
	{
		Clients.list=list;
	}
	public static List<MoneyTran> getTxList()
	{
	return li;
	}
	public static void setTxList(List<MoneyTran>li)
	{
		Clients.li=li;
	}
}
