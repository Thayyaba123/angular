import { Component } from '@angular/core';
import { Book } from '../app.books';
import { NgForm } from "@angular/Forms/forms";
import { BookService } from '../service/app.bookservice';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Component({
    selector : 'addbook-root',
    templateUrl : './app.addbookcomponent.html',
    providers : [BookService]
})
export class AddBookComponent{

    title : string = "addbookpage";
    bookList : any = [];

    book: Book = {
    bookId : null,
    bookName : null,
    bookCost : null,
    author : null
    };

    constructor(private httpClient : HttpClient){ }


    postData(bookForm:NgForm){
        alert("111" + JSON.stringify(bookForm));
        console.log(bookForm);
        this.httpClient.get('./assets/books.json').subscribe(
      bookForm => {
        this.bookList = bookForm as string [];	 // FILL THE ARRAY WITH DATA.
        //  console.log(this.arrBirds[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
    }

    
}