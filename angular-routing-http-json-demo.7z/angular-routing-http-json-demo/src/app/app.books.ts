export class Book{
    bookId : number;
    bookName : string;
    bookCost : number;
    author : string;
}