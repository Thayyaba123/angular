import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';
import { ListBookDetailsComponent } from './listBooks/app.booklistcomponent';
import { AddBookComponent } from './addBook/app.addbookcomponent';
import { HttpClientModule } from '@angular/common/http';

const bookRoutes : Routes = [
  {path:'',redirectTo:'listAllBooks',pathMatch:'full'},
  {path:'listAllBooks',component:ListBookDetailsComponent},
  {path:'addBook',component:AddBookComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    ListBookDetailsComponent,
    AddBookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(bookRoutes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
