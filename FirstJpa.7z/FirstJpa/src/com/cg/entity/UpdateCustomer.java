package com.cg.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UpdateCustomer {
	public static void main(String arg[])
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("firstjpa");
		EntityManager entitymanager=emf.createEntityManager();
		entitymanager.getTransaction().begin();
		Customer customer=entitymanager.find(Customer.class, 3534);
		
		customer.setAddress("uk");
		customer.setName("john");
		entitymanager.persist(customer);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		emf.close();
	}

}
