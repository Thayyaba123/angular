package com.cg.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SaveCustomer {
	public static void main(String arg[])
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("firstjpa");
		EntityManager entitymanager=emf.createEntityManager();
		entitymanager.getTransaction().begin();
		Customer customer=new Customer();
		customer.setId(3534);
		customer.setAddress("andhra");
		customer.setName("thayyaba");
		entitymanager.persist(customer);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		emf.close();
	}

}
