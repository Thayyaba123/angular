package main;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import WalletException.WaExceptions;
import customer.Customer;


import service.bank_Service;
public class Main
{
	public static void main(String[] args) throws WaExceptions {

		Scanner x = null;

		bank_Service s = new bank_Service();

		String continueChoice = "";

		do {

			System.out.println("****** WALLET APPLICATION ******");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT");
			System.out.println("4.WITHDRAW");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			int choice = 0;
			boolean choiceFlag = false;

			do {
				x = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = x.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:

						String name = "";
						boolean nameFlag = false;

						do {
							x = new Scanner(System.in);
							System.out.println("Enter  name");
							try {
								name = x.nextLine();
								s.validateName(name);
								nameFlag = true;
								break;
							} catch (WaExceptions e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						String address = "";
						boolean addressFlag= false;
						do {
						x = new Scanner(System.in);
							System.out.println("Enter address:");
							try {
								address = x.nextLine();
								s.validateAddress(address);
								addressFlag = true;
								break;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("address should be alphabets only");
							} catch (WaExceptions e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);

						String phone = "";
						boolean phoneFlag= false;
						do {
						x = new Scanner(System.in);
							System.out.println("Enter phone number:");
							try {
								phone = x.nextLine();
								s.validatePhone(phone);
								addressFlag = true;
								break;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("please enter valid number");
							} catch (WaExceptions e) {
								phoneFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!phoneFlag);
						String account = null;
						boolean amountFlag= false;
						do {
						x = new Scanner(System.in);
							System.out.println("Enter account number:");
							try {
								account = x.nextLine();
								s.validateAccount(account);
								amountFlag = true;
								break;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("account number shound contain numbers only");
							} catch (WaExceptions e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!amountFlag);
						
						System.out.println("enter the amount you want to diposite in wallet");
                            double amount=x.nextDouble();

						// Product product = new Product(productId, productName, productCost, quantity);
                            Customer c = new Customer(name,address,phone,amount,account);
						int id = s.addCustomer(c);
						System.out.println("id: " + id);
						System.out.println("**** aCCOUNT GENERATED SUCCESSFULLY*****");

						
						break;
					case 2:

						int id1 = 0;
						boolean idFalg = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id1 = x.nextInt();
								idFalg = true;
						
								try {
									 double c11 = s.searchId(id1);
									System.out.println(c11);
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								idFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!idFalg);

						break;

					case 3:

						int id2 = 0;
						boolean id2Falg = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id2 = x.nextInt();
								idFalg = true;
						System.out.println("enter the amount to diposite");
								try {
									double amount1=0.00;
									amount1=x.nextDouble();
									System.out.println("ypur depositr amount is:"+amount1);
									 double c11 = s.searchId(id2,amount1);
									System.out.println("total amount is"+c11);
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								idFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!idFalg);

						
						break;

					/*case 4:

						int id3 = 0;
						boolean id2Falg = false;
						do {
							x = new Scanner(System.in);
							System.out.println("Enter wlallet id:");
							try {
								id2 = x.nextInt();
								idFalg = true;
						System.out.println("enter the amount to diposite");
								try {
									double amount1=0.00;
									amount1=x.nextDouble();
									System.out.println("ypur depositr amount is:"+amount1);
									 double c11 = s.searchId(id2,amount1);
									System.out.println("total amount is"+c11);
								} catch (WaExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								idFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!idFalg);

						
						break;*/

					
					case 7:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("input should be 1, 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			x = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = x.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		x.close();
	}
}
