package Clients;

import java.util.ArrayList;
import java.util.List;

import customer.Customer;


//public Customer(String name,String address,String phone,Double amount,String accountno,Long id)
public class Clients {
	private static List<Customer>list=new ArrayList<>();
	static {
		list.add(new Customer("Nasreen","chennai","9966769316",5000.00,"423643435",234));
		
	}
	public static List<Customer> getList()
	{
		return list;
	}
	public static void setlist(List<Customer>list)
	{
		Clients.list=list;
	}
}
