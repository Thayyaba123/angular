package customer;

public class Balance 
{

}
