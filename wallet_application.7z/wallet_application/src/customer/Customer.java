package customer;

public class Customer 
{
private String name;
private String address;
private String phone;
private Double amount;
private int id;
private String accountno;
public Customer() {
	
}
public Customer(String name,String address,String phone,Double amount,String accountno)
{ super();
	this.name=name;
	this.address=address;
	this.phone=phone;
	this.amount=amount;
	this.accountno=accountno;
}
public Customer(String name,String address,String phone,Double amount,String accountno,int i)
{ super();
	this.name=name;
	this.address=address;
	this.phone=phone;
	this.amount=amount;
	this.accountno=accountno;
	this.id=i;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getPhone() {
	return phone;
}

public void setPhone(String phone) {
	this.phone = phone;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getAccountno() {
	return accountno;
}

public void setAccountno(String accountno) {
	this.accountno = accountno;
}


@Override
public String toString() {
	return "customer [accountno=" + accountno + ", address=" + address + ", amount=" + amount + ", id=" + id + ", name="
			+ name + ", phone=" + phone + "]";
}
}
