package service;

import java.util.regex.Pattern;


import WalletException.WaExceptions;
import customer.Customer;
import dao.Bank_Dao;

public class bank_Service implements Bank_Service_Interface {
Bank_Dao d=new Bank_Dao();
	public void validateName(String name) throws WaExceptions {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]+";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new WaExceptions("first letter should be capital ");
		}
	}

	public void validateAddress(String address) throws WaExceptions {
		String addressRegEx = "[a-zA-Z ]+";
		if (!Pattern.matches(addressRegEx, address)) {
			throw new WaExceptions("address should be alphabets only");
		}
		
	}

	public void validatePhone(String phone) throws WaExceptions {
		String phoneRegEx = "[7-9]{1}[0-9]{9}";
		if (!Pattern.matches(phoneRegEx,phone)) {
			throw new WaExceptions("enter valid number");
		}
		
	}

	public void validateAccount(String account) throws WaExceptions {
		String accountRegEx = "[0-9]{10}";
		if (!Pattern.matches(accountRegEx,account)) {
			throw new WaExceptions("enter valid number");
		}
		
	}

	public int addCustomer(Customer c) throws WaExceptions {
		return d.addCustomer(c);
		
	}

	public double searchId(int id1) throws WaExceptions {
	
		return d.searchId(id1);
	}

	public double searchId(int id2, double amount1) throws WaExceptions {
	
		return d.searchId(id2,amount1);
	}

	
}
