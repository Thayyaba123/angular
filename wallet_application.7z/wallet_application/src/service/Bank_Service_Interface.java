package service;

import WalletException.WaExceptions;
import customer.Customer;

public interface Bank_Service_Interface {
	public void validateName(String name) throws WaExceptions;
	public void validateAddress(String address) throws WaExceptions;
	public void validatePhone(String phone) throws WaExceptions;
	public void validateAccount(String account) throws WaExceptions;
	public int addCustomer(Customer c) throws WaExceptions;
	public double searchId(int id1) throws WaExceptions;
	public double searchId(int id2, double amount1) throws WaExceptions;
}
