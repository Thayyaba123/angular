package dao;



import java.util.List;

import Clients.Clients;

import WalletException.WaExceptions;
import customer.Customer;




public class Bank_Dao implements Bank_Dao_Interface {

	public int addCustomer(Customer c) throws WaExceptions {
		int id = (int) (Math.random() * 1000);
		c.setId(id);

		List<Customer> c1 = Clients.getList();
		c1.add(c);

		// PMSUtil.getList().add(product);

		return id;
	
	}

	public double searchId(int id1) throws WaExceptions {
	

		List<Customer> list = Clients.getList();
		double customerData = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id1) {
				customerData = customer.getAmount();
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}

		return customerData;
	}

	public double searchId(int id2, double amount1) throws WaExceptions {
		List<Customer> list = Clients.getList();
		double customerData = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id2) {
				customerData = customer.getAmount()+amount1;
				/*Customer cust=new Customer();
				double a=cust.setAmount(customerData);*/
				
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}

		return customerData;
		
	}

}
