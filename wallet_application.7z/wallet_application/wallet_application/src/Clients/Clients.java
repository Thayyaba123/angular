package Clients;

import java.util.ArrayList;
import java.util.List;


import customer.Customer;
import customer.MoneyTran;


//public Customer(String name,String address,String phone,Double amount,String accountno,Long id)
public class Clients {
	private static List<Customer>list=new ArrayList<>();
	private static List<MoneyTran>li=new ArrayList<>();
	
	public static List<Customer> getList()
	{
		return list;
	}
	public static void setlist(List<Customer>list)
	{
		Clients.list=list;
	}
	public static List<MoneyTran> getTxList()
	{
	return li;
	}
	public static void setAmountList(List<MoneyTran>li)
	{
		Clients.li=li;
	}
}

