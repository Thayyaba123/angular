package customer;

import java.time.LocalDateTime;

public class MoneyTran {
	private String name;
	public MoneyTran() {
		super();// TODO Auto-generated constructor stub
	}
	public MoneyTran(String name,double money,LocalDateTime date)
	{
		this.date=date;
		this.name=name;
		this.money=money;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	private double money;
	private LocalDateTime date;
	@Override
	public String toString() {
		return "MoneyTran [name=" + name + ", money=" + money + ", date=" + date + "]";
	}

}
