package dao;

import WalletException.WaExceptions;

import customer.Customer;

public interface Bank_Dao_Interface {
	public int addCustomer(Customer c) throws WaExceptions;
	public double searchId(int id1) throws WaExceptions;
//	public double searchId(int id2, double amount1) throws WaExceptions;
	
	//void addBalance(Balance sss) throws WaExceptions;
}
