package dao;



import java.time.LocalDateTime;
import java.util.List;

import Clients.Clients;

import WalletException.WaExceptions;
import customer.Customer;
import customer.MoneyTran;




public class Bank_Dao implements Bank_Dao_Interface {

	public int addCustomer(Customer c) throws WaExceptions {
		
		int id = (int) (Math.random() * 1000);
		c.setId(id);

		List<Customer> c1 = Clients.getList();
		c1.add(c);

		// PMSUtil.getList().add(product);

	
	return id;
	}

	public double searchId(int id1) throws WaExceptions {
	

		List<Customer> list = Clients.getList();
		double customerData = 0.00;
		boolean flag = false;

		for (Customer balance : list) {
			if (balance.getId() == id1) {
			customerData = balance.getBalance();
			LocalDateTime now=LocalDateTime.now();
			MoneyTran m=new MoneyTran("deposite",customerData,now);
			List<MoneyTran> c1 = Clients.getTxList();
			c1.add(m);
			
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}

		return customerData;
	}

	public double searchId(int id2, double amount1) throws WaExceptions {
		List<Customer> list = Clients.getList();
		double customerData = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id2) {
				
		
				customerData = customer.getBalance()+amount1;
				//Customer cust=new Customer();
			customer.setBalance(customerData);
			
				
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}
		
		return customerData;
}
//withdraw amount
	public double searchwithdrawId(int id3, double amount2) throws WaExceptions{
		List<Customer> list = Clients.getList();
		double customerData1 = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id3) {
				
		
				customerData1 = customer.getBalance()-amount2;
			customer.setBalance(customerData1);
			
				
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}
		
		return customerData1;
	
	}
//fund transfer
	public double searchfundId(int id4, double amount3) throws WaExceptions{
		List<Customer> list = Clients.getList();
		double customerData2 = 0.00;
		boolean flag = false;

		for (Customer customer : list) {
			if (customer.getId() == id4) {
				
		
				customerData2 = customer.getBalance()-amount3;
			customer.setBalance(customerData2);
			
				
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new WaExceptions("No product present with the given id");
		}
		
		return customerData2;
	
	}

	public List<MoneyTran> getTransaction()  throws WaExceptions{
		
		return Clients.getTxList();
	}

	}
