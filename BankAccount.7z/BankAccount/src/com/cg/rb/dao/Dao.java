package com.cg.rb.dao;
import java.util.HashMap;
import java.util.Map;
import com.cg.rb.bean.Account;
import com.cg.rb.bean.Transaction;
import com.cg.rb.bean.Wallet;
import com.cg.rb.bean.WalletTrans;
public class Dao implements DaoInterface
{
	Map<Integer,Account> acc_Db = new HashMap<Integer, Account>();
	Map<Integer,Wallet> wDb = new HashMap<Integer, Wallet>();
	Map<Integer,Transaction> tDb = new HashMap<Integer, Transaction>(); 
	Map<Integer,WalletTrans> wtDb = new HashMap<Integer, WalletTrans>();
	Transaction trans = new Transaction();
	
	public Dao()
	{
		acc_Db.put(1, new Account(1,"thayyaba", "9080706050", 50000));
		acc_Db.put(2, new Account(2,"mamatha", "9180706050", 25200));
		acc_Db.put(3, new Account(3,"jhansi", "9280706050", 10060));
		acc_Db.put(4, new Account(4,"Akshaya", "9380706050", 10500));
		acc_Db.put(5, new Account(5,"saileela", "9480706050", 31500));
		
		wDb.put(1, new Wallet(1,0));
		wDb.put(2, new Wallet(2,0));
		wDb.put(3, new Wallet(3,0));
		wDb.put(4, new Wallet(4,0));
		wDb.put(5, new Wallet(5,0));
		
		trans.addToTransactionList(50000 + "cr -> \t" + 1);
		storeIntoTransactDb(1, trans);
		
		trans.addToTransactionList(25000 + "cr -> \t" + 2);
		storeIntoTransactDb(2, trans);
		
		trans.addToTransactionList(10000 + "cr -> \t" + 3);
		storeIntoTransactDb(3, trans);
		
		trans.addToTransactionList(12500 + "cr -> \t" + 4);
		storeIntoTransactDb(4, trans);
		
		trans.addToTransactionList(37500 + "cr -> \t" + 5);
		storeIntoTransactDb(5, trans);
	}
	
	public boolean checkCredentials(int userName, String passWord)
	{
		if(acc_Db.containsKey(userName))
		{
			Account credentials = acc_Db.get(userName);
			if(credentials.getMobileNumber().equals(passWord)) 
				return true;
			else
				return false;
		}	
		else
			return false;
	}
	
	public void storeIntoAccDb(Account account) 
	{
		acc_Db.put(account.getAccountNumber(), account);
	}
	
	public Account getFromAccDb(int accountNumber) 
	{
		return acc_Db.get(accountNumber);
	}
	
	public void storeIntoWalletDb(Wallet wallet) 
	{
		wDb.put(wallet.getWalletID(),wallet);
	}
	
	public Wallet getFromWalletDb(int wID) 
	{
		return wDb.get(wID);
	}
	
	public void storeIntoTransactDb(int accountNumber, Transaction transactions)
	{
		tDb.put(accountNumber, transactions);
	}
	
	public Transaction getFromTransactDb(int accountNumber) 
	{
		return	tDb.get(accountNumber);
	}
	
	public void storeIntoWalletTransactDb(int walletID, WalletTrans walletTransactions)
	{
		wtDb.put(walletID, walletTransactions);
	}
	
	public WalletTrans getFromWalletTransactionsDatabase(int walletID) 
	{
		return	wtDb.get(walletID);
	}
	
	public int getAccountCount()
	{
		return acc_Db.size();
	}
	
	//Print all data from map 
	public void getTransactionFromWalletDatabase()
	{
		for(Integer aKey : wtDb.keySet())
		{
				WalletTrans aValue = wtDb.get(aKey);
				System.out.println(aKey +" "+ aValue);	
		}
	}
	
	//Print all data from map 
	public void getTransactionFromAccountDatabase()
	{
		for(Integer aKey : tDb.keySet())
		{
			Transaction aValue = tDb.get(aKey);
			System.out.println(aKey +" "+ aValue);	
		}
	}

	public Account getFromAccountDatabase(int userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void storeIntoWalletTransactDb(int walletID, Wallet walletTransactions) {
		// TODO Auto-generated method stub
		
	}
}
