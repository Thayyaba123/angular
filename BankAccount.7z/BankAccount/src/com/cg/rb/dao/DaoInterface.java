package com.cg.rb.dao;

import com.cg.rb.bean.Account;
import com.cg.rb.bean.Transaction;
import com.cg.rb.bean.Wallet;
import com.cg.rb.bean.WalletTrans;

public interface DaoInterface {
	public boolean checkCredentials(int userName, String passWord);
	public void storeIntoAccDb(Account account);
	public Account getFromAccDb(int accountNumber) ;
	public void storeIntoWalletDb(Wallet wallet);
	public Wallet getFromWalletDb(int wID) ;
	public void storeIntoTransactDb(int accountNumber, Transaction transactions);
	public Transaction getFromTransactDb(int accountNumber);
	public void storeIntoWalletTransactDb(int walletID, Wallet walletTransactions);
	
}
