package com.cg.rb.bean;
import java.util.ArrayList;
import java.util.List;

public class Transaction
{
List<String> transList = new ArrayList<String>();
	
	public List<String> getTransactList() 
	{
		return transList;
	}

	public void setTransactionList(List<String> transactList) 
	{
		this.transList = transactList;
	}

	public void addToTransactionList(String transaction) 
	{
		transList.add(transaction);
	}
	
	@Override
	public String toString()
	{
		for(String transactions : transList)
			return transactions;
		return null;
	}	
}
