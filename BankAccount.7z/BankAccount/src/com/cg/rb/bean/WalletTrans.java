package com.cg.rb.bean;
import java.util.ArrayList;
import java.util.List;
public class WalletTrans
{
List<String> walletTransactList = new ArrayList<String>();
	
	public List<String> getTransactList() 
	{
		return walletTransactList;
	}

	public void setTransactList(List<String> transactList) 
	{
		this.walletTransactList = transactList;
	}

	public void addToTransactionList(String transaction) 
	{
		walletTransactList.add(transaction);
	}
	
	@Override
	public String toString()
	{
		for(String transactions : walletTransactList)
			return transactions;
		return null;
	}
}
