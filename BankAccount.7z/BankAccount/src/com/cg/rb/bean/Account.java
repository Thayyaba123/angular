package com.cg.rb.bean;

public class Account extends Wallet
{
	private int acc_Nmber;
	private String acc_Name;
	private String PhoneNum;
	private double amnt;

	public Account(int i, String string, String string2, int j)
	{
		this.acc_Nmber = 0;
		this.acc_Name = null;
		this.PhoneNum = null;
		this.amnt = 0;
	}
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	

	public void Account(int acc_Nmber, String acc_Name, String PhoneNum, int amnt)
	{
		this.acc_Nmber = acc_Nmber;
		this.acc_Name = acc_Name;
		this.PhoneNum = PhoneNum;
		this.amnt = amnt;
	}
	
	public int getAccountNumber() 
	{
		return acc_Nmber;
	}
	
	public void setAccountNumber(int accountNumber) 
	{
		this.acc_Nmber=acc_Nmber;
	}
	
	public String getName() 
	{
		return acc_Name;
	}
	
	public void setName(String name) 
	{
		this.acc_Name = name;
	}
	
	public String getMobileNumber() 
	{
		return PhoneNum;
	}
	
	public void setPhone(String Phone) 
	{
		this.PhoneNum = Phone;
	}
	
	public double getAmount() 
	{
		return amnt;
	}

	public void setAmount(double amount) 
	{
		this.amnt = amount;
	}
	
	@Override
	public String toString()
	{
		return ""
				+"\nAccount Number: " + acc_Nmber
				+"\nHolder's Name: " + acc_Name 
				+"\nMobile Number: " + PhoneNum
				+"\nAccount Balance: " + amnt
				+"\nWallet ID: " + getWalletID()
				+"\nWallet Balance: " + getWalletAmnt()
				;
	}
}
