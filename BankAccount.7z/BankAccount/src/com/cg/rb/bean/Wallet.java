package com.cg.rb.bean;

public class Wallet
{
	private int wID;
	private double Cash;
	
	public Wallet()
	{
		this.wID = 0;
		this.Cash = 0;
	}
	
	public Wallet(int walletID, int walletAmount)
	{
		this.wID = walletID;
		this.Cash = walletAmount;
	}
	
	public int getWalletID() 
	{
		return wID;
	}
	
	public void setWalletID(int walletID) 
	{
		this.wID = walletID;
	}
	
	public double getWalletAmnt() 
	{
		return Cash;
	}
	
	public void setWalletAmnt(double wallet) 
	{
		this.Cash = wallet;
	}
	
	@Override
	public String toString()
	{
		return ""
				+"Wallet ID: " + wID
				+"Wallet Money: " + Cash + "\n";
	}	
}
