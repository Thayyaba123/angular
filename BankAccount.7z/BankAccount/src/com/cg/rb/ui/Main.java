package com.cg.rb.ui;
import com.cg.rb.service.Bank;

public class Main 
{
	public static void main(String[] args) 
	{
		Bank bank = new Bank();
		bank.appUI();
	}	
}
