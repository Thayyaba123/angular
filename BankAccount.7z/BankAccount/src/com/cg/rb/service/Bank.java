package com.cg.rb.service;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;
import com.cg.rb.bean.Account;
import com.cg.rb.bean.Transaction;
import com.cg.rb.bean.Wallet;
import com.cg.rb.bean.WalletTrans;
import com.cg.rb.dao.Dao;
public class Bank implements BankInterface
{

	public int accountNumber;
	public int walletID;
	boolean bool;
	double transferableAmount = 0;
	
	Scanner ip = new Scanner(System.in);
	Account acc = new Account();
	Dao dao = new Dao();
	Transaction tx = new Transaction();
	WalletTrans walletTransact = new WalletTrans();

	//Create Account
	public void createAccount() 
	{
		Account newAcc = new Account();
		Wallet newWallet = new Wallet();
		
		//Account Data
		newAcc.setAccountNumber(++accountNumber + 5);

		System.out.print("Enter Your Name:");
		newAcc.setName(ip.next());
		System.out.println();

		System.out.print("Enter Your Mobile Number:");
		newAcc.setPhone(ip.next());
		System.out.println();

		System.out.print("Enter Initial Deposit Amount:");
		newAcc.setAmount(ip.nextInt());
		creditAccount(newAcc.getAmount());
		System.out.println();
		
		//Store Account Data into DB
		dao.storeIntoAccDb(newAcc);

		//Wallet Data
		newWallet.setWalletID(++walletID + 5);
		newWallet.setWalletAmnt(0);

		//Store Wallet Data into DB
		dao.storeIntoWalletDb(newWallet);
		
		//Initial Transaction
		tx.addToTransactionList(newAcc.getAmount() + "cr -> \t" + newAcc.getAmount());
		dao.storeIntoTransactDb(newAcc.getAccountNumber(), tx);

		//Display Account Info
		System.out.println("........Account Created Succesfully.........");
		System.out.println("\nYour Account Number(UserName): " + "RB000" + newAcc.getAccountNumber());
		System.out.println("Your Mobile Number(Password): " + newAcc.getMobileNumber());
		System.out.println("Your Wallet Id " + "WM000" + newWallet.getWalletID());
	}

	//Shows Balance in Account & Wallet
	public void showBalance() 
	{
		bool = true;

		while (bool) 
		{
			System.out.println("\nEnter your choice:");
			System.out.println("\n0.Back");
			System.out.println("1.Account");
			System.out.println("2.Wallet");

			System.out.print("\nYour Choice: ");
			switch (ip.nextInt()) 
			{
				case 0: bool = false; mainMenu(); break;
				case 1: System.out.println("\nYour Account Balance: " + acc.getAmount()); break;
				case 2: System.out.println("\nYour Wallet Balance: " + acc.getWalletAmnt());break;
				default: System.out.println("Invalid option"); showBalance(); break;
			}
		}
	}

	//Credit in Account 
	public void depositAmount() 
	{
		System.out.print("\nEnter the amount yout want to deposit: ");
		transferableAmount = ip.nextInt();
		creditAccount(transferableAmount);
		getAccountBalance.accept("");
		
	}

	//Debit from Account
	public void withdrawAmount() 
	{
		System.out.print("\nEnter the amount yout want to withdraw: ");
		transferableAmount = ip.nextInt();
		debitAccount(transferableAmount);
		getAccountBalance.accept("");		
	}

	//Transfer funds
	public void fundTransfer() 
	{
		bool = true;
		
		while (bool) 
		{

			System.out.println("\nEnter your choice");
			System.out.println("\n0.Back");
			System.out.println("1. Bank to Wallet");
			System.out.println("2. Wallet to Bank");
			System.out.println("3. Bank to Bank");
			System.out.println("4. Wallet to Wallet");
			System.out.println("5. Bank to Another Wallet");

			try 
			{
				System.out.print("\nYour Choice: ");
				switch (ip.nextInt()) 
				{
					case 0: { bool = false; mainMenu(); break; }
				
					//Transfer from Bank to Wallet
					case 1: 
					{
						System.out.print("\nEnter the amount to be transfered to wallet: ");
						transferableAmount = ip.nextInt();
					
						debitAccount(transferableAmount);
						creditWallet(transferableAmount);
					
						getAccountBalance.accept("");
						getWalletBalance.accept("");
					}
					break;

					//Transfer from Wallet to Bank
					case 2: 
					{
						System.out.print("\nEnter the amount to be transfered to Bank: ");
						transferableAmount = ip.nextInt();

						debitWallet(transferableAmount);
						creditAccount(transferableAmount);
						
						getAccountBalance.accept("");
						getWalletBalance.accept("");
					}
					break;
					
					//Transfer from Bank to Another bank
					case 3: 
					{
					
						System.out.print("\nEnter account number to which you want to transfer the amount: RB000");
						int accountNumber = ip.nextInt();

						if (validateAccountNumber(accountNumber)) 
						{
							Account anotherAccount = dao.getFromAccDb(accountNumber);
						
							System.out.print("\nEnter the amount to be transfered to Another Account: ");
							transferableAmount = ip.nextInt();
						
							debitAccount(transferableAmount);
							creditAccount(transferableAmount, anotherAccount);
						
							getAccountBalance.accept("");
						} 	
					}
					break;

					//Transfer from Wallet to Another Wallet
					case 4: 
					{
						System.out.print("\nEnter wallet ID to which you want to transfer the amount: WM000");
						int walletID = ip.nextInt();

						if (validateAccountNumber(walletID))
						{
							Wallet anotherWallet = dao.getFromWalletDb(walletID);
						
							System.out.print("\nEnter the amount to be transfered to Another Wallet: ");
							transferableAmount = ip.nextInt();
							
							debitWallet(transferableAmount);
							creditWallet(transferableAmount, anotherWallet);
							
							getWalletBalance.accept("");
						} 	
					}
					break;

					//Transfer from Bank to Another Wallet
					case 5: 
					{
						System.out.print("\nEnter wallet ID to which you want to transfer the amount: WM000");
						int walletID = ip.nextInt();

						if (validateAccountNumber(walletID)) 
						{
							Wallet anotherWallet = dao.getFromWalletDb(walletID);
							System.out.print("\nEnter the amount to be transfered to Another Wallet: ");
							transferableAmount = ip.nextInt();
						
							debitAccount(transferableAmount);
							creditWallet(transferableAmount, anotherWallet);
							
							getAccountBalance.accept("");
						} 				
					 }
					 break;

					default: { System.out.println("\nInvalid option"); fundTransfer(); break; }
				}
				
			}
			
			catch (Exception e) 
			{
				System.out.println("\nInvalid Operation");
				System.out.println(e);
				bool = false;
			} 
			
			finally 
			{
				if (!bool)
					mainMenu();
			}
		}
	}
	
	//Get Transaction History
	public void printTransaction() 
	{
		Transaction transaction = dao.getFromTransactDb(acc.getAccountNumber());
 WalletTrans walletTransaction = dao.getFromWalletTransactionsDatabase(acc.getWalletID());

		bool = true;

		while (bool) 
		{
			System.out.println("\nEnter your choice: ");
			System.out.println("\n0.Back");
			System.out.println("1.Account");
			System.out.println("2.Wallet");

			System.out.print("Your Choice: ");
			switch (ip.nextInt()) 
			{
				case 0: { bool = false; mainMenu(); break; }

				case 1: 
				{
					if (transaction != null) 
					{
						System.out.println("\nTransaction History:");
						System.out.println("Cr./Dr. \tBalance");
						for (String transactions : transaction.getTransactList())
							System.out.println(transactions);
					} 
				
					else System.out.println("\nNo Transactions Yet!");
					//db.getTransactionFromAccountDatabase();
				}
				break;

				case 2: 
				{
					if (walletTransaction != null) 
					{
						System.out.println("\nTransaction History:");
						System.out.println("Cr./Dr. \tBalance");
						for (String walletTransactions : walletTransaction.getTransactList())
							System.out.println(walletTransactions);
						//db.getDataFromMap();
					} 
				
					else System.out.println("\nNo Transactions Yet!");
					//db.getTransactionFromWalletDatabase();
					
				}
				break;

				default: System.out.println("Invalid option");
			}
		}

	}

	public void accountDetails() 
	{
		System.out.println(acc);
	}
	
	/* ---------------------------------------- Supporting Methods---------- ------------------------------*/
	
	//User Interface
		public void appUI() 
		{
			bool = true;

			while (bool) 
			{
				System.out.println("\n---------Welcome To Rockstar Bank---------");
				System.out.println("\nEnter Your Choice: ");
				System.out.println("\n0. Terminate App");
				System.out.println("1. Login");
				System.out.println("2. Create Account.");

				System.out.print("\nYour Choice: ");
				switch (ip.nextInt()) 
				{
					case 0: { bool = false; break; }
					case 1: { validateAccount(); bool = false; break; }			
					case 2: { createAccount(); break;}					
					default: { System.out.println("\nInvalid option"); break; }
				}
			}
		}
		
		Consumer<String> getAccountBalance = balance -> System.out.println("\nUpdated Account Balance: " + acc.getAmount());
		Consumer<String> getWalletBalance = balance -> System.out.println("\nUpdated Wallet Balance: " + acc.getWalletAmnt());
		
		//Validate User Credentials
		public void validateAccount()
			{
				bool = true;

				while (bool) 
				{
					System.out.print("\nEnter UserName (Account Number): RB000");
					int userName = ip.nextInt();
					
					System.out.print("Enter PassWord (Mobile Number): ");
					String passWord = ip.next();
					
					//Validates UserName, Password 
					if (dao.checkCredentials(userName, passWord))
					{
						this.acc = dao.getFromAccDb(userName);
							
						if(acc.getWalletID() == 0)
						this.acc.setWalletID(acc.getAccountNumber());
							
						//Get Initial Deposit Transaction
						if(tx.getTransactList().isEmpty() && acc.getAccountNumber() <= dao.getAccountCount())
						{
							tx.addToTransactionList(acc.getAmount() + "cr -> \t" + acc.getAmount());
							dao.storeIntoTransactDb(acc.getAccountNumber(), tx);
						}
							
							mainMenu();
							bool = false;					
					} 
					
					else System.out.println("\nWrong Credentials..! Try Again.");
				}						
			}
		
			//Main menu
			public void mainMenu() 
			{
				bool = true;

				while (bool) 
				{
					System.out.println("\nEnter Your Choice:");
					System.out.println("\n0. Terminate App");
					System.out.println("1. Check Balance");
					System.out.println("2. Deposit Amount");
					System.out.println("3. Withdraw Amount");
					System.out.println("4. Fund Transfer");
					System.out.println("5. Transaction History");
					System.out.println("6. Account Details");
					System.out.println("7. Logout");

					System.out.print("\nYour Choice: ");
					switch (ip.nextInt()) 
					{
						case 0: bool = false; break; 
						case 1: showBalance(); break;
						case 2:	depositAmount(); break;
						case 3: withdrawAmount(); break;
						case 4: fundTransfer(); break;
						case 5: printTransaction(); break;
						case 6: accountDetails(); break;
						case 7: appUI(); /*transact = null; walletTransact = null;*/break;
						default: System.out.println("Invalid option"); break;
					}
				}
			}
			
	private boolean validateAccountNumber(int accountNumber) 
	{
		if (acc.getAccountNumber() > 0 && accountNumber <= dao.getAccountCount()) 
		{
			return true;
		}
		else
		{
			System.out.println("\nAccount doesn't exist!, Try again.");
			fundTransfer();
			return false;
		}
	}
	
	
	private void creditAccount(double transferableAmount) 
	{
		acc.setAmount(acc.getAmount() + transferableAmount);
		
		tx.addToTransactionList(transferableAmount + "cr -> \t" + acc.getAmount());
		dao.storeIntoTransactDb(acc.getAccountNumber(), tx);	
	}	
	
	private void creditAccount(double transferableAmount, Account anotherAccount) 
	{
		anotherAccount.setAmount(anotherAccount.getAmount() + transferableAmount);
		
		if(dao.getFromTransactDb(anotherAccount.getAccountNumber()) == null) 
		{
			Transaction anotherTransact = new Transaction();
			
			anotherTransact.addToTransactionList(transferableAmount + "cr -> \t" + anotherAccount.getAmount());
			dao.storeIntoTransactDb(anotherAccount.getAccountNumber(), anotherTransact);
		}
		else
		{
			Transaction anotherTransact = dao.getFromTransactDb(anotherAccount.getAccountNumber());
			List<String> existingList = anotherTransact.getTransactList();
			
			existingList.add(transferableAmount + "cr -> \t" + anotherAccount.getAmount());
			anotherTransact.setTransactionList(existingList);
			dao.storeIntoTransactDb(anotherAccount.getAccountNumber(), anotherTransact);
		}
		
	}

	private void debitWallet(double transferableAmount) 
	{
		if(acc.getWalletAmnt() >= transferableAmount) 
		{
			acc.setWalletAmnt(acc.getWalletID() - transferableAmount);
			walletTransact.addToTransactionList(transferableAmount + "dr -> \t" + acc.getWalletID());
			dao.storeIntoWalletTransactDb(acc.getWalletID(), walletTransact);
		}
		
		else System.out.println("Insufficient Balance");
	}
	
	private void creditWallet(double transferableAmount, Wallet anotherWallet) 
	{
		anotherWallet.setWalletAmnt(anotherWallet.getWalletAmnt() + transferableAmount);
		
		if(dao.getFromWalletTransactionsDatabase(anotherWallet.getWalletID()) == null) 
		{
			WalletTrans anotherWalletTransact = new WalletTrans();
			anotherWalletTransact.addToTransactionList(transferableAmount + "cr -> \t" + anotherWallet.getWalletAmnt());
			dao.storeIntoWalletTransactDb(anotherWallet.getWalletID(), anotherWalletTransact);
		}
		else
		{
			WalletTrans anotherWalletTransact = dao.getFromWalletTransactionsDatabase(anotherWallet.getWalletID());
			List<String> existingList = anotherWalletTransact.getTransactList();
			existingList.add(transferableAmount + "cr -> \t" + anotherWallet.getWalletAmnt());
			anotherWalletTransact.setTransactList(existingList);
			dao.storeIntoWalletTransactDb(anotherWallet.getWalletID(), anotherWalletTransact);
		}
	}


	private void creditWallet(double transferableAmount) 
	{
		acc.setWalletAmnt(acc.getWalletAmnt() + transferableAmount);
		
		walletTransact.addToTransactionList(transferableAmount + "cr -> \t" + acc.getWalletAmnt());
		dao.storeIntoWalletTransactDb(acc.getWalletID(), walletTransact);	
	}

	private void debitAccount(double transferableAmount) 
	{
		if(acc.getAmount() >= transferableAmount) 
		{
			acc.setAmount(acc.getAmount() - transferableAmount);
			
			tx.addToTransactionList(transferableAmount + "dr -> \t" + acc.getAmount());
			dao.storeIntoTransactDb(acc.getAccountNumber(), tx);
		}
		else System.out.println("Insufficient Balance");
	}
}
