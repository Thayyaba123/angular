package com.cg.rb.service;

public interface BankInterface {
	public void createAccount();
	public void showBalance();
	public void depositAmount();
	public void withdrawAmount();
	public void fundTransfer();
	public void printTransaction();
	public void accountDetails();
	public void validateAccount();
}
