package Userinterface;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import Exception.HMException;
import bean.Customer;
import service.Hotel_service;

public class Main 
{
public static void main(String arg[]) throws HMException
{
	Scanner x=null;
	Hotel_service s=new Hotel_service();
	String continueChoice = "";
	do {
	System.out.println("****** Hotel management System ******");
	System.out.println("1.Add customer");
	System.out.println("2.get all Customers");
	System.out.println("3.search customer");
	System.out.println("4.checkout");
	System.out.println("5.exit");

	int choice = 0;
	boolean choiceFlag = false;

	do {
		x = new Scanner(System.in);
		System.out.println("Enter your choice");
		try {
			choice = x.nextInt();
			choiceFlag = true;

			switch (choice) {

			case 1:

				String name=" ";
				boolean nameFlag = false;

				do {
					x = new Scanner(System.in);
					System.out.println("Enter name");
					try {
						name = x.nextLine();
						s.validateName(name);
						nameFlag = true;
						break;
					} catch (HMException e) {
						nameFlag = false;
						System.err.println(e.getMessage());
					}
				} while (!nameFlag);

				String address = "";
				boolean addressFlag= false;
				do {
				x = new Scanner(System.in);
					System.out.println("Enter address:");
					try {
						address = x.nextLine();
						s.validateAddress(address);
						addressFlag = true;
						break;
					} catch (InputMismatchException e) {
						addressFlag = false;
						System.err.println("address should be alphabets only");
					} catch (HMException e) {
						addressFlag = false;
						System.err.println(e.getMessage());
					}
				} while (!addressFlag);

				String phone = "";
				boolean phoneFlag= false;
				do {
				x = new Scanner(System.in);
					System.out.println("Enter phone number:");
					try {
						phone = x.nextLine();
						s.validatePhone(phone);
						addressFlag = true;
						break;
					} catch (InputMismatchException e) {
						addressFlag = false;
						System.err.println("please enter valid number");
					} catch (HMException e) {
						phoneFlag = false;
						System.err.println(e.getMessage());
					}
				} while (!phoneFlag);
				
				x = new Scanner(System.in);
					System.out.println("Enter room number:");
					int rno=x.nextInt();
					int id = (int) (Math.random() * 100000);

				// Product product = new Product(productId, productName, productCost, quantity);
				Customer c = new Customer(id,name,address,phone,rno);
				 s.addCustomer(c);
				break;
			case 2:

				List<Customer> c1 = null;
				try {
					c1 = s.getAllCustomers();
					for (Customer out : c1) {
						System.out.println(out);
					}
				} catch (HMException e) {
					System.err.println(e.getMessage());
				}
				break;


			case 3:

			int id1=0;
				boolean id1Falg = false;
				do {
					x = new Scanner(System.in);
					System.out.println("Enter id:");
					try {
						id1 = x.nextInt();
						id1Falg = true;
						Customer c11;
						try {
							c11= s.searchCustomer(id1);
							System.out.println(c11);
						} catch (HMException e1) {
							System.err.println(e1.getMessage());
						}

					} catch (InputMismatchException e) {
						id1Falg = false;
						System.err.println("name should be alphabets");
					}
				} while (!id1Falg);

				break;
			case 4:

				int id2=0;
					boolean id2Falg = false;
					
					do {
				
						x = new Scanner(System.in);
						System.out.println("do you want to check out");
						String a=x.nextLine();
						if(a.equalsIgnoreCase("yes"))
						System.out.println("Enter id:");
						try {
							id1 = x.nextInt();
							x.nextLine();
							id1Falg = true;
							Customer c11;
							try {
								c11= s.searchCustomer(id1);
								System.out.println(c11);
								System.out.println("checked out successfully");
								break;
								
								
							} catch (HMException e1) {
								System.err.println(e1.getMessage());
							}

						} catch (InputMismatchException e) {
							id1Falg = false;
							System.err.println("name should be alphabets");
						}
					} while (!id2Falg);
					
						
					break;
			
			case 5:
				System.out.println("*** Thank you *** ");
				System.exit(0);
				break;

			default:
				choiceFlag = false;
				System.out.println("input should be 1, 2 or 3");
				break;
			}

		} catch (InputMismatchException e) {
			choiceFlag = false;
			System.err.println("please enter only digits");
		}

	} while (!choiceFlag);

	x = new Scanner(System.in);
	System.out.println("do you want to continue again [yes/no]");
	continueChoice = x.nextLine();

} while (continueChoice.equalsIgnoreCase("yes"));

x.close();
}
}
