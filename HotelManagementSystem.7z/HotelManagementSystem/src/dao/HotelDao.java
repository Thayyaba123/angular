package dao;

import java.util.List;

import Exception.HMException;

import bean.Customer;
import pack1.Guests;


public class HotelDao implements HotelDao_Interface{

	public void addCustomer(Customer c) {
		List<Customer> c1=Guests.getList();
		c1.add(c);
		
	}
	public List<Customer> getAllCustomers()
	{
		
		return Guests.getList();
	}
	
		
	
	public Customer searchCustomer(int id1) throws HMException {
		List<Customer> list = Guests.getList();
		Customer c1=null;
		boolean flag = false;

		for (Customer c : list) {
			if (c.getId() == id1) {
				c1 = c;
				flag = true;
				break;
			}
		}
		if (flag==false) {
			throw new HMException("No person is present with that name");
		}	
return c1;
	}

}
