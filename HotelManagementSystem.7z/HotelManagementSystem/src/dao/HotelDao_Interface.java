package dao;

import java.util.List;

import Exception.HMException;
import bean.Customer;

public interface HotelDao_Interface {
	public void addCustomer(Customer c) throws HMException;
	 List<Customer> getAllCustomers() throws HMException;
	  Customer searchCustomer(int id1) throws HMException;
}
