package service;

import Exception.HMException;
import bean.Customer;

public interface Hotel_Interface {

	public  void validateName(String name) throws HMException;

	public void validateAddress(String address)throws HMException ;

	public void addCustomer( Customer c)throws HMException;
	 Customer searchCustomer(int id1) throws HMException;
	//void validateRno(String rno) throws HMException;
}
