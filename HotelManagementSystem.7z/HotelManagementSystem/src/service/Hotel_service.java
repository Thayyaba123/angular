package service;

import java.util.List;
import java.util.regex.Pattern;

import Exception.HMException;
import bean.Customer;
import dao.HotelDao;


public class Hotel_service implements Hotel_Interface {
HotelDao d=new HotelDao();
	public  void validateName(String name) throws HMException
	{
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]+";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new HMException("first letter should be capital ");
		}	
	}

	public void validateAddress(String address)throws HMException {
		String addressRegEx = "[a-zA-Z ]+";
		if (!Pattern.matches(addressRegEx, address)) {
			throw new HMException("address should be alphabets only");
		}
	}

	@Override
	public void addCustomer(Customer c) throws HMException {
		d.addCustomer(c);
		
	}

	public void validatePhone(String phone) throws HMException {
		String phoneRegEx = "[7-9]{1}[0-9]{9}";
		if (!Pattern.matches(phoneRegEx,phone)) {
			throw new HMException("enter valid number");
		}
		
	}

	public List<Customer> getAllCustomers() throws HMException{
		
		return  d.getAllCustomers();
	}

	public Customer searchCustomer(int id1) throws HMException
	{
		return d.searchCustomer(id1);
	
	}

	/*@Override
	public void validateRno(String  rno) throws HMException {
		String rnoRegEx = "[0-9]";
		if (!Pattern.matches(rnoRegEx,rno)) {
			throw new HMException("enter valid number");
		}*/
		
	}

	

