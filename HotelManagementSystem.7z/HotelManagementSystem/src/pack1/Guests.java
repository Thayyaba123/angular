package pack1;

import java.util.ArrayList;
import java.util.List;

import bean.Customer;

public class Guests 
{
private static List<Customer>list=new ArrayList<>();
static {
	list.add(new Customer(4567,"bhoomi","chennai","9966769316",21));
	list.add(new Customer(34567,"john","usa","9966756546",22));
	list.add(new Customer(6756,"jackson","uk","9966769316",23));
	list.add(new Customer(3556,"chawla","nepal","9966769316",24));
	list.add(new Customer(34345,"pooja","goa","9966554316",25));
	list.add(new Customer(34545,"yasir","delhii","9644769316",26));
}
public static List<Customer> getList()
{
	return list;
}
public static void setlist(List<Customer>list)
{
	Guests.list=list;
}
}
