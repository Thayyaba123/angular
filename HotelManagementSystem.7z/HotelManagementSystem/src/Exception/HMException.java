package Exception;

public class HMException extends Exception {

	public HMException(String message) {
		super(message);
	}

}
