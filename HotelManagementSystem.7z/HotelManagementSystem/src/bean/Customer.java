package bean;

public class Customer 
{
	private int id;
private String name;
private String address;
private String number;

private int roomnumber;

public Customer(int id, String name, String address, String number, int rno)
{
	super();
	this.id=id;
	this.name=name;
	this.address=address;
	this.number=number;
	
	this.roomnumber=rno;
}

@Override
public String toString() {
	return "Customer [id="+id+"name=" + name + ", address=" + address + ", number=" + number + 
			", roomnumber=" + roomnumber + "]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}

public int getRoomnumber() {
	return roomnumber;
}
public void setRoomnumber(int roomnumber) {
	this.roomnumber = roomnumber;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
}
