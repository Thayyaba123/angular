import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Exception.HMException;
import bean.Customer;
import dao.HotelDao;



public class HotelDaoTest {

	HotelDao dao=null;
	@Before
	public void setup() throws Exception
	{
		dao=new HotelDao();
	}
	@After 
	public void tearDown() throws Exception
	{
		dao=null;
	}
	@Test
	public void testAddCustomer() throws HMException
	{
		Customer c = new Customer(22334,"Raju","nepal","9966769316", 34);
		dao.addCustomer(c);
		assertNotNull(c);
				
	}
	@Test
	public void testAddCustomerNull() throws HMException
	{
		Customer c = new Customer(22334,"Raju","nepal","9966769316", 34);
		dao.addCustomer(c);
		assertNull(c);
				
	}
	@Test
	public void testGetAllCustomers() throws HMException {

		List<Customer> list = dao.getAllCustomers();
		assertTrue(list.size() > 0);
	}

	@Test
	public void testGetAllCustomersNotNull() throws HMException {

		List<Customer> list = dao.getAllCustomers();
		assertNotNull(list);
	}

	@Test
	public void testSearchProduct() {

		try {
			Customer c = dao.searchCustomer(333);
			assertNotNull(c);
		} catch (HMException e) {
		}
	}
	@Test
	public void testSearchProductNull() {

		try {
			Customer c = dao.searchCustomer(333);
			assertNull(c);
		} catch (HMException e) {
		}
	}

}
